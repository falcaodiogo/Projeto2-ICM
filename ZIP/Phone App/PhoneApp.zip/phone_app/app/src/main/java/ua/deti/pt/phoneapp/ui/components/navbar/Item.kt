package ua.deti.pt.phoneapp.ui.components.navbar

import androidx.compose.ui.graphics.vector.ImageVector

open class Item(val path: String, val title: String, val icon: ImageVector)