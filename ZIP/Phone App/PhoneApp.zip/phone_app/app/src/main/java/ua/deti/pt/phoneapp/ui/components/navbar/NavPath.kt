package ua.deti.pt.phoneapp.ui.components.navbar

enum class NavPath {
    HOME, NOTIFICATIONS, SLEEP, SETTINGS, EXERCISES
}