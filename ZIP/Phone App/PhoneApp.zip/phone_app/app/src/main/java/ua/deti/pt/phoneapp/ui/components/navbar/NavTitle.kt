package ua.deti.pt.phoneapp.ui.components.navbar

object NavTitle {
    const val HOME = "Home"
    const val NOTIFICATIONS = "Alerts"
    const val EXERCISES = "Exercises"
    const val SLEEP = "Sleep"
    const val SETTINGS = "Settings"
}